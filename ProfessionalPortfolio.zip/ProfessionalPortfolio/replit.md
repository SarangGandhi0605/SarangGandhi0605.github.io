# Sarang Gandhi Portfolio

## Overview

This is a personal portfolio website for Sarang Gandhi, a high school student passionate about computer science and technology. The portfolio is built as a static website using vanilla HTML and CSS, featuring a clean, modern design with a dark theme. The site showcases personal information, resume download, and academic projects in a professional format.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Technology Stack**: Pure HTML5 and CSS3 (no frameworks)
- **Design Approach**: Single-page application with multiple sections
- **Styling Strategy**: Custom CSS with modern design principles
- **Typography**: Google Fonts (Inter font family) for professional appearance
- **Layout**: Responsive design using CSS Grid and Flexbox
- **Color Scheme**: Enhanced dark theme with tech-nature inspired colors (#58a6ff primary, #9effe5 secondary, #a78bfa accent, #0f1117 background)
- **Animations**: Custom CSS keyframe animations with JavaScript scroll triggers
- **Effects**: Cursor-reactive background gradients, frosted glass cards, subtle glow effects

### File Structure
```
/
├── index.html          # Main HTML file containing all content
├── style.css          # Enhanced stylesheet with animations and modern effects
├── script.js          # JavaScript for cursor effects and scroll animations
└── attached_assets/
    └── Sarang Gandhi_Resume (3)_1752673761744.pdf  # Resume file for download
```

## Key Components

### 1. Header Section
- Personal branding with name and tagline
- Centered layout with emphasis on typography
- Blue accent color for name highlighting

### 2. About Me Section
- Personal introduction and background
- Paragraph format with readable typography

### 3. Resume Section
- Download functionality for PDF resume
- Call-to-action button design

### 4. Academic Projects Section
- Grid-based layout for project cards (currently showing one project)
- Structured format with title, date, and bullet-point details

### Design System
- **Colors**: Dark theme (#0f1117 background, #c9d1d9 text, #58a6ff accent)
- **Typography**: Inter font family with various weights (300-700)
- **Spacing**: Consistent rem-based spacing system
- **Layout**: Container-based design (max-width: 1000px) with responsive padding

## Data Flow

This is a static website with no dynamic data flow. Content is hardcoded in HTML:
1. Browser loads HTML file
2. CSS styles are applied
3. Google Fonts are loaded externally
4. Resume download link opens PDF in new tab when clicked

## External Dependencies

### Third-Party Services
- **Google Fonts**: Inter font family loaded via CDN
  - Weights: 300, 400, 500, 600, 700
  - Loading strategy: `display=swap` for performance

### Assets
- Resume PDF file (referenced but hosted locally)

## Deployment Strategy

### Static Hosting
- **Type**: Static website suitable for any web hosting service
- **Requirements**: Basic HTTP server capability
- **Files**: Only HTML, CSS, and PDF files needed
- **Performance**: Minimal load times due to lightweight architecture

### Deployment Options
- GitHub Pages
- Netlify
- Vercel
- Traditional web hosting
- Replit hosting

### Browser Compatibility
- Modern browsers supporting CSS Grid and Flexbox
- Google Fonts fallback to system fonts
- Responsive design for mobile and desktop

## Technical Decisions

### Why Vanilla HTML/CSS
- **Simplicity**: No build process or framework complexity needed
- **Performance**: Minimal file sizes and fast loading
- **Maintenance**: Easy to update and modify content
- **Compatibility**: Works across all browsers and hosting platforms

### Design Choices
- **Dark Theme**: Modern, professional appearance popular in tech industry
- **Typography-First**: Clean, readable text with Inter font for professional feel
- **Minimal Layout**: Focus on content without distractions
- **Mobile-First**: Responsive design principles applied throughout