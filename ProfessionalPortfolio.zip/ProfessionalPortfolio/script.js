// Cursor glow effect
document.addEventListener('DOMContentLoaded', function() {
    const cursorGlow = document.querySelector('.cursor-glow');
    let isDesktop = window.innerWidth > 768;
    
    // Track cursor position
    document.addEventListener('mousemove', function(e) {
        if (!isDesktop) return;
        
        const x = e.clientX;
        const y = e.clientY;
        
        cursorGlow.style.left = x + 'px';
        cursorGlow.style.top = y + 'px';
        cursorGlow.style.opacity = '1';
    });
    
    // Hide cursor glow when mouse leaves window
    document.addEventListener('mouseleave', function() {
        cursorGlow.style.opacity = '0';
    });
    
    // Update desktop detection on resize
    window.addEventListener('resize', function() {
        isDesktop = window.innerWidth > 768;
        if (!isDesktop) {
            cursorGlow.style.opacity = '0';
        }
    });
    
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                const animationType = element.getAttribute('data-animation');
                
                // Add animation class based on type
                if (animationType) {
                    element.classList.add('animate');
                    
                    // Special handling for staggered animations
                    if (animationType === 'slide-up') {
                        const cards = element.querySelectorAll('.activity-card');
                        cards.forEach((card, index) => {
                            setTimeout(() => {
                                card.style.opacity = '1';
                                card.style.transform = 'translateY(0)';
                            }, index * 100);
                        });
                    }
                    
                    if (animationType === 'pulse') {
                        const categories = element.querySelectorAll('.skills-category');
                        categories.forEach((category, index) => {
                            setTimeout(() => {
                                category.style.opacity = '1';
                                category.style.transform = 'scale(1)';
                            }, index * 100);
                        });
                    }
                    
                    if (animationType === 'bounce-fade') {
                        const items = element.querySelectorAll('.contact-item');
                        items.forEach((item, index) => {
                            setTimeout(() => {
                                item.style.opacity = '1';
                                item.style.transform = 'translateY(0)';
                            }, index * 100);
                        });
                    }
                }
                
                // Unobserve after animation is triggered
                observer.unobserve(element);
            }
        });
    }, observerOptions);
    
    // Observe all animated sections
    const animatedElements = document.querySelectorAll('[data-animation]');
    animatedElements.forEach(element => {
        observer.observe(element);
    });
    
    // Dynamic background gradient effect
    let gradientX = 20;
    let gradientY = 80;
    let direction = 1;
    
    function updateBackground() {
        gradientX += direction * 0.1;
        gradientY += direction * 0.05;
        
        if (gradientX > 80 || gradientX < 20) {
            direction *= -1;
        }
        
        document.body.style.background = `
            radial-gradient(circle at ${gradientX}% ${gradientY}%, rgba(88, 166, 255, 0.15) 0%, transparent 50%),
            radial-gradient(circle at ${100-gradientX}% ${100-gradientY}%, rgba(158, 255, 229, 0.15) 0%, transparent 50%),
            radial-gradient(circle at 40% 40%, rgba(167, 139, 250, 0.1) 0%, transparent 50%),
            linear-gradient(135deg, #0f1117 0%, #161b22 100%)
        `;
    }
    
    // Start background animation
    setInterval(updateBackground, 100);
    
    // Enhanced cursor interaction for cards
    const cards = document.querySelectorAll('.project-card, .activity-card, .community-card, .skills-category, .contact-item');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            if (!isDesktop) return;
            
            // Create temporary enhanced glow
            const rect = this.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            
            cursorGlow.style.width = '600px';
            cursorGlow.style.height = '600px';
            cursorGlow.style.background = 'radial-gradient(circle, rgba(88, 166, 255, 0.15) 0%, transparent 70%)';
        });
        
        card.addEventListener('mouseleave', function() {
            if (!isDesktop) return;
            
            // Reset glow to normal
            cursorGlow.style.width = '400px';
            cursorGlow.style.height = '400px';
            cursorGlow.style.background = 'radial-gradient(circle, rgba(88, 166, 255, 0.1) 0%, transparent 70%)';
        });
    });
    
    // Smooth scrolling for any anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add subtle parallax effect to header
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const header = document.querySelector('.header');
        if (header) {
            header.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
    });
});